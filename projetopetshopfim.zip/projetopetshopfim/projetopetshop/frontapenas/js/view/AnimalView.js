/**
 * Renderiza o formulário para criar um novo tbtipoanimal.
 * @return {string} HTML do formulário de criação de tbtipoanimal.
 */
function renderizarFormulario() {
    return `
            <form class="mt-3" id="formulario_tpanimal">
                <div class="form-group">
                    <label for="tpanimal_nome">Nome:</label>
                    <input type="text" class="form-control" id="tpanimal_nome_formulario">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
  }
  
  /**
   * Renderiza o formulário para atualizar um tbservico existente.
   * @param {Object} tbtipoanimal - O tbtipoanimal a ser atualizado.
   * @return {string} HTML do formulário de atualização de tbtipoanimal.
   */
  function renderizarFormularioAtualizar(tbtipoanimal) {
      return `
              <form class="mt-3" id="formulario_tpanimal_atualizar">
                  <input type="hidden" class="form-control" id="tpanimal_id_formulario" value="${tbtipoanimal.CoTipoAnimal}">
                  <div class="form-group">
                      <label for="tpanimal_nome">Tipo do animal:</label>
                      <input type="text" class="form-control" id="tpanimal_nome_formulario" value="${tbtipoanimal.NoTipoAnimal}">
                  </div>
                  <button type="submit" class="btn btn-primary mt-2">Salvar</button>
              </form>
          `;
  }
  
    /**
   * Renderiza a tabela de tbtipoanimal.
   * @param {Array} tbtipoanimal - Lista de tbservico a serem exibidas.
   * @return {string} HTML da tabela de tbservico.
   */
  function renderizarTabela(tbtipoanimal) {
    let tabela = `
            <table class="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>Tipo do animal</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
        `;
  
    tbtipoanimal.forEach((tbtipoanimal) => {
      tabela += `
                <tr>
                    <td>${tbtipoanimal.NoTipoAnimal}</td>
                    <td>
                      <button class="excluir-btn" tpanimal-id=${tbtipoanimal.CoTipoAnimal}>Excluir</button>
                      <button class="atualizar-btn" tpanimal-atualizar-id=${tbtipoanimal.CoTipoAnimal}>Atualizar</button>
                    </td>
                </tr>
            `;
    });
  
    tabela += `
                </tbody>
            </table>
        `;
  
    return tabela;
  }
  
  const AnimalView = {
      renderizarFormulario,
      renderizarTabela,
      renderizarFormularioAtualizar
  };
  
  export default AnimalView;
  