 /**
 * Renderiza o formulário para criar uma nova tarefa.
 * @return {string} HTML do formulário de criação de tarefa.
 */
 function renderizarFormulario() {
    return `
            <form class="mt-3" id="formulario_tbtipoanimal">
                <div class="form-group">
                    <label for="tipoanimal_titulo">Tipo Animal:</label>
                    <input type="text" class="form-control" id="tipoanimal_titulo_formulario">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
  }
  
  /**
   * Renderiza o formulário para atualizar uma tarefa existente.
   * @param {Object} tbtipoanimal - A tarefa a ser atualizada.
   * @return {string} HTML do formulário de atualização de tarefa.
   */
  function renderizarFormularioAtualizar(tbtipoanimal) {
      return `
              <form class="mt-3" id="formulario_tipoanimal_atualizar">
              <input type="hidden" class="form-control" id="tipoanimal_id_formulario" value="${tbtipoanimal.CoTipoAnimal}">
                  <div class="form-group">
                      <label for="tipoanimal_titulo">Tipo Animal:</label>
                      <input type="text" class="form-control" id="tipoanimal_titulo_formulario" value="${tbtipoanimal.CoTipoAnimal}">
                  </div>
                  <button type="submit" class="btn btn-primary mt-2">Salvar</button>
              </form>
          `;
  }
  
    /**
   * Renderiza a tabela de tarefas.
   * @param {Array} tbtipoanimal - Lista de tarefas a serem exibidas.
   * @return {string} HTML da tabela de tarefas.
   */
  function renderizarTabela(tbtipoanimal) {
    let tabela = `
            <table class="table table-striped mt-3">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
        `;
  
    tbtipoanimal.forEach((tbtipoanimal) => {
      tabela += `
                <tr>
                    <td>${tbtipoanimal.titulo}</td>
                    <td>
                      <button class="excluir-btn" tbtipoanimal-id=${tbtipoanimal.CoTipoAnimal}>Excluir</button>
                      <button class="atualizar-btn" tbtipoanimal-atualizar-id=${tbtipoanimal.CoTipoAnimal}>Atualizar</button>
                    </td>
                </tr>
            `;
    });
  
    tabela += `
                </tbody>
            </table>
        `;
  
    return tabela;
  }
  
  const TarefaView = {
      renderizarFormulario,
      renderizarTabela,
      renderizarFormularioAtualizar
  };
  
  export default TarefaView;