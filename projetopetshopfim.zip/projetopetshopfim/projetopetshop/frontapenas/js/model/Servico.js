export class Servico {
  constructor(NoServicos) {
      this._NoServicos = NoServicos;
      this._isCompleta = false;
  }

  set NoServicos(NoServicos){
    this._NoServicos = NoServicos;
  }


  set isCompleta (isCompleta){
    this._isCompleta = isCompleta ;
  }


  get NoServicos(){
    return this._NoServicos;
  }

  get isCompleta(){
    return this._isCompleta;
  }      
    

}