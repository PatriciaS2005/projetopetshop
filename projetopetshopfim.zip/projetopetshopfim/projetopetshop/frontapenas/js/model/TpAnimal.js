export class TipoAnimal {
  constructor(NoTipoAnimal) {
      this._NoTipoAnimal = NoTipoAnimal;
      this._isCompleta = false;
  }

  set NoTipoAnimal(NoTipoAnimal){
    this._NoTipoAnimal = NoTipoAnimal;
  }


  set isCompleta (isCompleta){
    this._isCompleta = isCompleta ;
  }


  get NoTipoAnimal(){
    return this._NoTipoAnimal;
  }

  get isCompleta(){
    return this._isCompleta;
  }      
    

}