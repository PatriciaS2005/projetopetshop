create table tbServicos (
 	CoServicos int PRIMARY KEY AUTO_INCREMENT,
    NoServicos varchar(300) not null,
    ValorServico decimal(10, 0) not null
);